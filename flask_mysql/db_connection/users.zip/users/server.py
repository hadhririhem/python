from flask import Flask, render_template, redirect, request

from users import User
app = Flask(__name__)
@app.route("/create")
def index():
    return render_template("create.html")

@app.route("/success", methods=["POST"])
def success():
    data = {
        "fname" : request.form["fname"],
        "lname" : request.form["lname"],
        "email" : request.form["email"]
    }
    User.save(data)
    return redirect("/display")

@app.route("/display")
def display() :  
    users = User.get_all()
    return render_template("display.html", users = users)

if __name__ == "__main__":
    app.run(debug=True)