import parent
print((locals))

